#!/usr/bin/env python
import numpy as np
import pylab as plt
from mpl_toolkits.mplot3d import axes3d

def mif(x,y):
  return np.exp(-(x**2+y**2))

Ro=5.
Nt=1e7
fmax=1.

u=np.random.random(Nt)
R=Ro*np.sqrt(u)
phi=2*np.pi*np.random.random(Nt)
z=fmax*np.random.random(Nt)

x=R*np.cos(phi)
y=R*np.sin(phi)

mask=z<=mif(x,y)
Nbajo=len(z[mask])

I=(np.float(Nbajo)/Nt)*fmax*(np.pi*Ro**2)
Ianalitico=np.pi*(1-np.exp(-Ro**2))
print I,Ianalitico

fig=plt.figure(1)
ax=fig.add_subplot(111,projection='3d')
ax.plot(x,y,z,'o')
#plt.show()
