#!/usr/bin/env python
import numpy as np
import pylab as plt

def mif(x):
  return x*np.exp(-x)

xo,xf=0.,5.
Ntotal=1e6

vector=np.linspace(xo,xf,1000)
fmax=np.max(mif(vector))
xran=(xf-xo)*np.random.random(Ntotal) + xo
yran=fmax*np.random.random(Ntotal)
mask = yran<= mif(xran)

Nbajo=mask.sum()
plt.subplot(121)
plt.plot(vector,mif(vector),'-',color='orange',lw=4)
#plt.plot(xran[mask],yran[mask],'ro',ms=5)
#plt.plot(xran,yran,'kx')

I=(float(Nbajo)/Ntotal)*((xf-xo)*fmax)
print 'Ivon_neuman=',I

def primitiva(x):
  return -(x+1)*np.exp(-x)

Iv=primitiva(xf)-primitiva(xo)
print 'Iverdad=',Iv 

plt.subplot(122)
plt.hist(xran[mask])
plt.show()
