#!/usr/bin/env python
import numpy as np
import scipy as sc
import pylab as plt
from mpl_toolkits.mplot3d import axes3d

def my_funtion(x):
  return x*np.exp(-x)

def my_funtion2(x,y):
  return np.exp(-(x**2+y**2))
xo,xf=-4.,4.
yo,yf=-4.,4.
Ntotal=1e4
vectorx=np.linspace(xo,xf,500)
vectory=np.linspace(yo,yf,500)

fmax=np.max(my_funtion2(vectorx,vectory))


xran=(xf-xo)*np.random.random(Ntotal)+xo
yran=(yf-yo)*np.random.random(Ntotal)+yo

wran=(fmax)*np.random.random(Ntotal)
mask=wran<=my_funtion2(xran,yran)

Nbajo=mask.sum()
I=(float(Nbajo)/Ntotal)*((xf-xo)*fmax*(yf-yo))
print "Integral", I

fig=plt.figure(1)
ax=fig.add_subplot(1,1,1,projection="3d")
#ax.plot_surface(vector,my_funtion(vector),"-",color="orange",lw=4) 
#plt.plot(xran,yran,wran,"kx") 
plt.plot(xran[mask],yran[mask],wran[mask],"bo",ms=5) 

x,y=plt.meshgrid(vectorx,vectory)
z=my_funtion2(x,y)
ax.plot_surface(x,y,z,cmap='autumn',alpha=0.3) 
#from mpl_toolkits.mplot3d import axes3d

plt.show()

