#!/usr/bin/env python
import numpy as np
import pylab as plt
import scipy

N=1e3
x1=np.random.random(N)
x2=np.random.random(N)

r=x1**(1./3.)
theta=np.arcsin(2*x2-1)
phi=2*np.pi*np.random.random(N)

#scipy.savetxt('esfera.dat',np.array([r,theta,phi]).T)
scipy.savetxt('esfera_mal.dat',np.array([x1,(np.pi)*x2+np.pi/2.,phi]).T)
