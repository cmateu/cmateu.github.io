#!/usr/bin/env python
import numpy as np
import pylab as plt

N=1e5
alpha=3.5
x=np.random.random(N)
y=(((alpha-1)**2)*x)**(1./(1-alpha))

dz=0.1
z=np.arange(dz,20.,dz)
plt.hist(y,bins=z,normed=True,log=True)
zo=z+dz/2.
plt.plot(zo,(1/(alpha-1))*(zo)**(-alpha),'ko')
plt.ylim(0.,4.)
plt.show()
