#!/usr/bin/env python
import numpy as np
import pylab as plt
import scipy.special
N=1e5
tau=0.5
x=np.random.random(N)
y=scipy.special.erfinv(2*x-1)

dz=0.1
z=np.arange(-4.,4.,dz)
plt.hist(y,bins=z,normed=True)
zo=z+dz/2.
plt.plot(zo,(1/np.sqrt(np.pi))*np.exp(-zo**2),'ko')
plt.show()
