#!/usr/bin/env python
import numpy as np
import pylab as plt

N=1e5
tau=0.5
x=np.random.random(N)
y=-tau*np.log(1-x)

dz=0.1
z=np.arange(0.,5*tau,dz)
plt.hist(y,bins=z,normed=True,log=True)
zo=z+dz/2.
plt.plot(zo,(1/tau)*np.exp(-zo/tau),'ko')
plt.show()
