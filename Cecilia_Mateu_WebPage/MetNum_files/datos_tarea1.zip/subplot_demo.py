#!/usr/bin/env python
import pylab as plt   #These are different ways of loading a library. 
import scipy
import numpy as np

#---------------------------------------------------------------------
#This program explains how to make 4 plots on a window using python
# (modified from the example on the matplotlib webpage
#---------------------------------------------------------------------

#This is a simple function definition in python
def f(t):
    s1 = np.cos(2*np.pi*t)
    e1 = np.exp(-t)
    return s1*e1

#Create some data
t1 = np.arange(0.0, 5.0, 0.1)
t2 = np.arange(0.0, 5.0, 0.02)
t3 = np.arange(0.0, 2.0, 0.01)

#Create a figure with arbitrary size (you can skip this line and python will create a figure with default properties)
fig=plt.figure(1,figsize=(12,6))

#Subplots will be layed-out on a 2x2 matrix 
#First subplot
plt.subplot(221)
plt.plot(t3, np.cos(2*np.pi*t3), 'r.')
plt.grid(True)
plt.xlabel('t (s)')
plt.ylabel('Undamped Oscillation')
plt.title('A tale of 4 subplots')
plt.axis([0,2,-1,1])

plt.subplot(222)
plt.plot(t1, f(t1), 'bo', t2, f(t2), 'k--')
plt.grid(True)
plt.xlabel('t (s)')
plt.ylabel('Damped Oscillation')
plt.title('Latex string: $f(t) = e^{-t}\cos{(\omega t+\phi)}$ ')
#axis([0,5,-1,1])

#Read data from a file
pdat=scipy.genfromtxt('datos_planetas.dat',comments='#') #The output is a 2-D array
#Give nice names to the relevant file columns
R, Period = pdat[:,0] , pdat[:,1]
#
plt.subplot(223)
plt.loglog(R,Period, 'go')
plt.grid(True)
plt.xlabel('Orbital Radius (km)')
plt.ylabel('Orbital Period (d)')

#Generate some random data drawn from a gaussian distribution
gaussian_devs=np.random.normal(loc=3.5, scale=1.0, size=2000)
#Plot
plt.subplot(224)
plt.hist(gaussian_devs,bins=20,histtype='step',color='orange',lw=3.,label='Bla')
plt.legend()
plt.xlabel('x')
plt.ylabel('N')

#Save figure and show it
plt.savefig('subplot_demo.png') #Python supports png, jpeg, pdf, eps, and lots more
plt.show()                      #Show the plot window
