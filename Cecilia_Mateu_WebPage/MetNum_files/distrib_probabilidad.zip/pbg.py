#!/usr/bin/env python
import numpy as np
import scipy
import scipy.stats
import pylab as plt

N=1e6
r=np.arange(0,N,1)
bin=scipy.stats.binom.pmf(r, N, 0.5)
poi=scipy.stats.poisson.pmf(r, N)
gau=scipy.stats.norm.pdf(r, N, 4.5)
plt.plot(r,bin,'o',label='Bin')
#plt.plot(r,poi,'o',label='Poi')
#plt.plot(r,gau,'o',label='Gau')
plt.legend()
plt.show()
