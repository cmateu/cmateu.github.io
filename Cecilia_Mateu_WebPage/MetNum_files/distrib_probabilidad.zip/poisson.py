#!/usr/bin/env python
import numpy as np
import scipy
import scipy.stats
import pylab as plt

i=0
for mu in np.arange(1,19,2):
 i=i+1
 fig=plt.figure(1,figsize=(12,8))
 ax=fig.add_subplot(3,3,i)
 r=np.arange(100)
 poi=scipy.stats.poisson.pmf(r, mu)
 ax.plot(r,poi,'o',color=plt.rcParams['axes.color_cycle'][i])
 ax.axvline(x=r[poi.argmax()],color=plt.rcParams['axes.color_cycle'][i],lw=4.,ls='--')
 ax.set_title('mu=%.1f' % (mu))
 ax.set_xlabel('r')
 ax.set_ylabel('prob(r|N,p)')
 ax.set_xlim(0,100)
 fig.suptitle('Distribucion de Poisson')
plt.tight_layout()
fig.subplots_adjust(bottom=0.06,top=0.9)
plt.show()
