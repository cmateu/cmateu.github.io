#!/usr/bin/env python
import numpy as np
import scipy
import scipy.stats
import pylab as plt

p,N=0.5,7
i=0
for p in np.arange(0.1,1.0,0.1):
 i=i+1
 fig=plt.figure(1,figsize=(8,6))
 ax=fig.add_subplot(3,3,i)
 r=np.arange(N)
 binomial=scipy.stats.binom.pmf(r, N, p)
 ax.plot(r,binomial,'o',color=plt.rcParams['axes.color_cycle'][i])
 ax.axvline(x=r[binomial.argmax()],color=plt.rcParams['axes.color_cycle'][i],lw=4.,ls='--')
 ax.set_title('N=%d (p=%.1f)' % (N,p))
 ax.set_xlabel('r')
 ax.set_ylabel('prob(r|N,p)')
 ax.set_xlim(0,20)
 fig.suptitle('Distribucion Binomial')
plt.tight_layout()
fig.subplots_adjust(bottom=0.06,top=0.9)
plt.show()
